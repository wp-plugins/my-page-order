<?php
/*
Plugin Name: My Page Order
Plugin URI: http://www.geekyweekly.com/mypageorder
Description: A Wordpress plugin to let you set the order of your pages
Version: 2.1
Author: froman118
Author URI: http://www.geekyweekly.com
Author Email: froman118@gmail.com
*/

function mypageorder_menu()
{   if (function_exists('add_submenu_page')) {
        $location = "../wp-content/plugins/";
        add_submenu_page("edit.php", 'My Page Order', 'My Page Order', 2,"mypageorder",'mypageorder');
    }
}
add_action('admin_menu', 'mypageorder_menu');

function mypageorder()
{
echo "<div class='wrap'>";

global $wpdb;
$mode = "";
$mode = $_GET['mode'];
$parentID = 0;
if (isset($_GET['parentID']))
	$parentID = $_GET['parentID'];

if($mode == "act_OrderPages")
{  $idString = $_GET['idString'];
    //echo $idString;
	$IDs = explode(",", $idString);
	$result = count($IDs);
	for($i = 1; $i < $result; $i++)
	{
		$wpdb->query("UPDATE $wpdb->posts SET menu_order = '$i' WHERE id ='$IDs[$i]'");
    }
	if(headers_sent())
   		echo "<script type='text/javascript'>location.href='edit.php?page=mypageorder';</script>";
	else
   		header("Location: edit.php?page=mypageorder");
}
else
{
	$results=$wpdb->get_results("SELECT * FROM $wpdb->posts WHERE post_parent = $parentID and post_type = 'page' ORDER BY menu_order ASC");
	echo "<h2>My Page Order</h2>Choose a page from the drop down to order its subpages or order the pages on this level with the up and down arrows.<br/><br/><form>";
	echo "&nbsp;<select name='pages'>";
	foreach($results as $row)
	{
		$postCount=$wpdb->get_row("SELECT count(*) as postsCount FROM $wpdb->posts WHERE post_parent = $row->ID and post_type = 'page' ", ARRAY_N);
		if($postCount[0] > 0)
	    	echo "<option value='$row->ID'>$row->post_title</option>";
	}
	echo "</select>";
	echo '&nbsp;<input type="button" name="edit" Value="Order Subpages" onClick="javascript:goEdit(this.form);">';

	echo "<br><br><table><tr><td><select name='order' id='order' size='10'>";
	foreach($results as $row)
	{
	    echo "<option value='$row->ID'>$row->post_title</option>";
	}
	echo "</select></td>";
	?>
	<td><input type="button" value="UP" onclick="moveEm('up','order');" /><br><input type="button" value="DOWN" onclick="moveEm('down','order');" />
	</td>
	<?php
	echo '<td>&nbsp;&nbsp;<input type="button" Value="Click to Order Pages" onclick="javascript:goOrderPages(this.form);"></td></tr></table>';

	echo "</form>";
}
echo "</div>";
?>

<script language="JavaScript" type="text/javascript">
    function goOrderPages (form) {
        var idString = "";
        for (i = 0; i < form.order.length; i++)
        {   idString += "," + form.order.options[i].value;
        }
        location.href="edit.php?page=mypageorder&mode=act_OrderPages&idString="+idString;
    }
    function moveEm(direction,listname) {
        dfr = document.getElementById("order");
        boxLen = dfr.length;
        currentItem = dfr.selectedIndex;

        if ((direction == 'up') && (currentItem > 0))
        {   selText = dfr.options[currentItem].text;
            swpText = dfr.options[currentItem - 1].text;
            selVal = dfr.options[currentItem].value;
            swpVal = dfr.options[currentItem - 1].value;
            dfr.options[currentItem - 1].text = selText;
            dfr.options[currentItem].text     = swpText;
            dfr.options[currentItem - 1].value = selVal;
            dfr.options[currentItem].value     = swpVal;
            dfr.selectedIndex = currentItem - 1;
        } else if ((direction == 'down') && (currentItem < boxLen - 1) && (currentItem != -1))
        {   selText = dfr.options[currentItem].text;
            swpText = dfr.options[currentItem + 1].text;
            selVal = dfr.options[currentItem].value;
            swpVal = dfr.options[currentItem + 1].value;
            dfr.options[currentItem + 1].text = selText;
            dfr.options[currentItem].text     = swpText;
            dfr.options[currentItem + 1].value = selVal;
            dfr.options[currentItem].value     = swpVal;
            dfr.selectedIndex = currentItem + 1;
        } else {}
    }
    function goEdit (form)
    {
		if(form.pages.value != "")
			location.href="edit.php?page=mypageorder&mode=dsp_OrderPages&parentID="+form.pages.value;
	}
</script>
<?php

}
?>